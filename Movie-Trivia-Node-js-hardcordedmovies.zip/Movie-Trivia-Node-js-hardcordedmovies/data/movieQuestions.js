 
// Choices will be presented in random order.
// points is optional, defaults to 10 if not specified.
// i was unable to get an API that can return top10 
//the only option i had was to create 8 variables containing 8 movies
//i experienced problems running jquery from the server side. upon research i found out i could use jsdom but i couldnt get it to run due to time

//var title1;
//var year1; 
//var uri = 'http://www.omdbapi.com/?t=True%20Grit&s=wrong%20turn%203'; 
	//	   $.ajax({
      //      type: "POST",
     //       url: uri,
       //     dataType: 'json',
       //     async: false,
			//cache:false,
        //    success: function (jsonData) {
   // debugger;
     //    movies = jsonData.Search[0];  
	//  title1=movies.Title;  
	//  year1 = movies.Year;

	  
	   //     }
       //   });
		  
		 
var movieQuestions = [{
    points: 10,
    question: "When was this movie released? Wrong turn 3",
    choices: [
        '2009',
        '2014',
        '2008',
        '2001'
    ]
},{
    points: 10,
    question: "When was this movie released Forrest Gump?",
    choices: [
        '1994',
        '2001',
        '1993',
        '2014'
    ]
},{
    question: "When was this movie released Fast Five?",
    choices: [
        '2011',
        '2012',
        '2010',
        '2013'
    ]
},{
    question: "When was this movie released Rio?",
    choices: [
        '2011',
        '2003',
        '2013',
        '2014'
    ]
},{
    question: "when was this movie released The Avengers?",
    choices: [
        '2012',
        '2009',
        '2014',
        '2011'
    ]
},{
    question: "when was this movie released Iron Man 3?",
    choices: [
        '2013',
        '2011',
        '2008',
        '2012'
    ]
},{
    question: "when was this movie released Finding Nemo?",
    choices: [
        '2003',
        '2001',
        '2004',
        '2014'
    ]
},{
    question: "When was this movie released Shrek 2?",
    choices: [
        '2004',
        '2006',
        '2013',
        '2001'
    ]
},{
    question: "When was this movie released The Dark Knight?",
    choices: [
        '2008',
        '2011',
        '2007',
        '2014'
    ]
}];

if (typeof module == 'object') {
    module.exports = movieQuestions;    
}
